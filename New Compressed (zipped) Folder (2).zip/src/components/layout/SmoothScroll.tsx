"use client";

import { useEffect } from "react";
import Lenis from "lenis";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

export default function SmoothScroll() {
  useEffect(() => {
    const motion = window.matchMedia("(prefers-reduced-motion: reduce)");
    let cleanup: (() => void) | undefined;

    const setup = () => {
      cleanup?.();
      cleanup = undefined;
      if (motion.matches) return;

      const lenis = new Lenis({
        autoRaf: false,
        lerp: 0.08,
        smoothWheel: true,
        syncTouch: false,
        anchors: { offset: -24 },
      });
      const tick = (time: number) => lenis.raf(time * 1000);
      const resize = () => lenis.resize();
      lenis.on("scroll", ScrollTrigger.update);
      gsap.ticker.add(tick);
      gsap.ticker.lagSmoothing(0);
      ScrollTrigger.addEventListener("refresh", resize);

      // Match the navigation's existing body scroll lock, including inertia.
      const header = document.querySelector(".site-header");
      const syncMenu = () => {
        if (header?.getAttribute("data-open") === "true") lenis.stop();
        else lenis.start();
      };
      const observer = new MutationObserver(syncMenu);
      if (header) observer.observe(header, { attributes: true, attributeFilter: ["data-open"] });
      syncMenu();

      cleanup = () => {
        observer.disconnect();
        ScrollTrigger.removeEventListener("refresh", resize);
        gsap.ticker.remove(tick);
        lenis.off("scroll", ScrollTrigger.update);
        lenis.destroy();
      };
    };

    setup();
    motion.addEventListener("change", setup);
    return () => {
      motion.removeEventListener("change", setup);
      cleanup?.();
    };
  }, []);

  return null;
}
