"use client";

import { useEffect, useRef } from "react";
import PortfolioButton from "@/components/ui/PortfolioButton";
import Image from "next/image";
import gsap from "gsap";
import { techStackData } from "@/data/techstack";

interface ToolIconProps {
  id: string;
  label: string;
  index: number;
}

function ToolIcon({ id, label, index }: ToolIconProps) {
  const src = `/dock-icons/${id}.png`;

  return (
    <div
      className="tool-icon"
      style={{ "--delay": `${index * 0.03}s` } as React.CSSProperties}
      data-tool-id={id}
    >
      <div className="tool-icon-inner">
        <Image
          src={src}
          alt={label}
          width={92}
          height={92}
          priority={index < 8}
          unoptimized
        />
      </div>
      <div className="tool-tooltip" role="tooltip">
        {label}
      </div>
    </div>
  );
}

export default function TechStack() {
  const sectionRef = useRef<HTMLElement>(null);
  const dockRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = dockRef.current;
    if (!container) return;

    // Set initial states
    gsap.set(container.querySelectorAll(".tool-tooltip"), {
      xPercent: -50,
      y: -8,
      scale: 0.7,
      opacity: 0,
    });
    gsap.set(container.querySelectorAll(".tool-icon-inner"), {
      transformOrigin: "50% 100%",
    });

    const onMove = (event: MouseEvent) => {
      const rows = Array.from(
        container.querySelectorAll<HTMLElement>(".tools-icons-row"),
      );
      if (!rows.length) return;

      // Find the single row closest to cursor vertical position
      let activeRowIndex = -1;
      let minDiffY = Infinity;

      rows.forEach((row, idx) => {
        const rect = row.getBoundingClientRect();
        const rowCenterY = rect.top + rect.height / 2;
        const diffY = Math.abs(event.clientY - rowCenterY);

        if (event.clientY >= rect.top - 24 && event.clientY <= rect.bottom + 24) {
          if (diffY < minDiffY) {
            minDiffY = diffY;
            activeRowIndex = idx;
          }
        }
      });

      rows.forEach((row, idx) => {
        if (idx === activeRowIndex) {
          const icons = row.querySelectorAll<HTMLElement>(".tool-icon");
          if (!icons.length) return;

          const firstIcon = icons[0];
          const iconWidth = firstIcon.offsetWidth;
          // Radius of influence around cursor: 2 icons wide
          const radius = iconWidth * 2.2;
          const maxScale = 1.35;
          const pointerX = event.clientX;

          icons.forEach((icon, i) => {
            const inner = icon.querySelector<HTMLElement>(".tool-icon-inner");
            const tooltip = icon.querySelector<HTMLElement>(".tool-tooltip");
            if (!inner || !tooltip) return;

            const iconRect = icon.getBoundingClientRect();
            const iconCenterX = iconRect.left + iconRect.width / 2;
            const distance = iconCenterX - pointerX;
            const absDist = Math.abs(distance);

            let scale = 1;
            let x = 0;

            if (absDist < radius) {
              const pct = 1 - absDist / radius; // 1 at center, 0 at edge of radius
              // Smooth cosine bell curve for scale
              const curve = (Math.cos((1 - pct) * Math.PI) + 1) / 2;
              scale = 1 + (maxScale - 1) * curve;

              // Gentle lateral nudge that naturally fades to 0 at radius edge
              const pushFactor = iconWidth * 0.12 * Math.sin(pct * Math.PI);
              x = distance > 0 ? pushFactor : -pushFactor;

              // Strict boundary guard: first and last icons can never push outside container
              if (i === 0 && x < 0) x = 0;
              if (i === icons.length - 1 && x > 0) x = 0;
            } else {
              scale = 1;
              x = 0;
            }

            gsap.to(inner, {
              duration: 0.22,
              x,
              scale,
              zIndex: Math.round(scale * 100),
              ease: "power2.out",
              overwrite: "auto",
            });

            const isHovered = absDist < iconWidth * 0.45;
            gsap.to(tooltip, {
              duration: 0.2,
              x: 0,
              y: isHovered ? 0 : -8,
              opacity: isHovered ? 1 : 0,
              scale: isHovered ? 1 : 0.7,
              zIndex: Math.round(scale * 100) + 10,
              ease: "power2.out",
              overwrite: "auto",
            });
          });
        } else {
          // Strictly reset inactive rows
          const inners = row.querySelectorAll<HTMLElement>(".tool-icon-inner");
          const tooltips = row.querySelectorAll<HTMLElement>(".tool-tooltip");

          gsap.to(inners, {
            duration: 0.3,
            scale: 1,
            x: 0,
            zIndex: 1,
            ease: "power2.out",
            overwrite: "auto",
          });
          gsap.to(tooltips, {
            duration: 0.2,
            opacity: 0,
            y: -8,
            scale: 0.7,
            x: 0,
            ease: "power2.out",
            overwrite: "auto",
          });
        }
      });
    };

    const onLeave = () => {
      const inners = container.querySelectorAll<HTMLElement>(".tool-icon-inner");
      const tooltips = container.querySelectorAll<HTMLElement>(".tool-tooltip");

      gsap.to(inners, {
        duration: 0.35,
        scale: 1,
        x: 0,
        zIndex: 1,
        ease: "power2.out",
        overwrite: "auto",
      });
      gsap.to(tooltips, {
        duration: 0.25,
        opacity: 0,
        y: -8,
        scale: 0.7,
        x: 0,
        ease: "power2.out",
        overwrite: "auto",
      });
    };

    container.addEventListener("mousemove", onMove);
    container.addEventListener("mouseleave", onLeave);

    return () => {
      container.removeEventListener("mousemove", onMove);
      container.removeEventListener("mouseleave", onLeave);
      gsap.killTweensOf(container.querySelectorAll(".tool-icon-inner, .tool-tooltip"));
    };
  }, []);

  return (
    <section
      className="tools-section"
      id="stack"
      ref={sectionRef}
      aria-labelledby="tech-stack-heading"
    >
      <div className="tools-container">
        {/* Section Header */}
        <header className="tools-header">
          <p className="tools-eyebrow">{techStackData.eyebrow}</p>
          <h2 className="tools-title" id="tech-stack-heading">
            {techStackData.title}
          </h2>
        </header>

        {/* Dock Magnification Rows */}
        <div
          className="tools-icons-container"
          ref={dockRef}
          aria-label="Technologies and frameworks"
        >
          {techStackData.rows.map((rowItems, rowIndex) => (
            <div
              key={`tech-row-${rowIndex}`}
              className="tools-icons-row"
              data-row-index={rowIndex}
            >
              {rowItems.map((tool, itemIndex) => (
                <ToolIcon
                  key={`${tool.id}-${itemIndex}`}
                  id={tool.id}
                  label={tool.label}
                  index={rowIndex * 9 + itemIndex}
                />
              ))}
            </div>
          ))}
        </div>

        {/* Section Footer */}
        <footer className="tools-footer">
          <p className="tools-desc">{techStackData.description}</p>
          <PortfolioButton href={techStackData.ctaHref} label={techStackData.ctaText} variant="secondary" />
        </footer>
      </div>
    </section>
  );
}
