"use client";

import Image from "next/image";
import dynamic from "next/dynamic";
import { siteConfig } from "@/data/siteConfig";
import { useFittedText } from "@/hooks/useFittedText";

const RipplePortrait = dynamic(
  () => import("@/components/visuals/RipplePortrait"),
  { ssr: false },
);

export default function Hero() {
  const firstName = useFittedText();
  const lastName = useFittedText();

  return (
    <section className="hero" id="hero" aria-labelledby="hero-title">
      <div className="hero-background" aria-hidden="true">
        <Image
          src={siteConfig.heroBackground}
          alt=""
          fill
          preload
          sizes="100vw"
          className="hero-backdrop"
        />
        <div className="hero-portrait-layer">
          <Image
            src={siteConfig.portrait}
            alt=""
            fill
            preload
            sizes="(max-width: 809px) 215vw, 1400px"
            className="hero-portrait"
          />
        </div>
        <RipplePortrait />
      </div>
      <div className="hero-content">
        <div className="hero-top">
          <p className="hero-descriptor">
            {siteConfig.hero.descriptor[0]}
            <br />
            {siteConfig.hero.descriptor[1]}
          </p>
        </div>
        <div className="hero-bottom">
          <div className="hero-heading-row">
            <h1
              className="hero-first-name"
              id="hero-title"
              aria-label={siteConfig.name}
            >
              <span className="fitted-text" ref={firstName.wrapper}>
                <span
                  className="fitted-text-inner"
                  ref={firstName.text}
                  aria-hidden="true"
                >
                  {siteConfig.hero.firstName}
                </span>
              </span>
            </h1>
            <div className="hero-roles">
              {siteConfig.hero.roles.map((role) => (
                <p className="hero-role" key={role.firstLine}>
                  {role.firstLine}
                  <br />
                  {role.secondLine}
                </p>
              ))}
            </div>
          </div>
          <div className="hero-last-name" aria-hidden="true">
            <span className="fitted-text" ref={lastName.wrapper}>
              <span className="fitted-text-inner" ref={lastName.text}>
                {siteConfig.hero.lastName}
              </span>
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
