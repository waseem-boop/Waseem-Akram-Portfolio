"use client";

import { useRef } from "react";
import { siteConfig } from "@/data/siteConfig";
import { useStatementAnimation } from "@/hooks/useStatementAnimation";
import StatementDraft from "@/components/visuals/StatementDraft";

export default function Statement() {
  const section = useRef<HTMLElement>(null);
  useStatementAnimation(section);

  return (
    <section
      ref={section}
      id="about"
      className="statement-section"
      aria-labelledby="statement-title"
    >
      <StatementDraft />
      <h2 id="statement-title" className="sr-only">
        {siteConfig.statement.paragraphs.join(" ")}
      </h2>
      <div className="statement-stack" aria-hidden="true">
        {siteConfig.statement.paragraphs.map((paragraph) => (
          <p className="statement-text" key={paragraph}>
            {paragraph}
          </p>
        ))}
      </div>
    </section>
  );
}
