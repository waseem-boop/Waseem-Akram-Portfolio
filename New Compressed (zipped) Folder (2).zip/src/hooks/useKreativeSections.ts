"use client";

import { useLayoutEffect, type RefObject } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

export function useSelectedWork(ref: RefObject<HTMLElement | null>) {
  useLayoutEffect(() => {
    const section = ref.current;
    if (!section) return;
    const media = gsap.matchMedia();
    media.add({
      desktop: "(min-width: 992px)",
      large: "(min-width: 1280px)",
      reduced: "(prefers-reduced-motion: reduce)",
    }, (context) => {
      if (!context.conditions?.desktop || context.conditions.reduced) return;
      // Kreativedge home-three: heading size keyframes at 20% and 36%
      // of section entry -> section bottom reaching the viewport bottom.
      const heading = section.querySelector<HTMLElement>(".work-header h2");
      let measuredHeight = 0;
      gsap.timeline({
        scrollTrigger: {
          trigger: section, start: "top bottom", end: "bottom bottom",
          scrub: 0.8, invalidateOnRefresh: true,
          // Font-size animation changes document flow. Re-measure the cards
          // and later sticky sections once the scrub settles, not every frame.
          onScrubComplete: () => {
            const height = section.offsetHeight;
            if (Math.abs(height - measuredHeight) > 1) {
              measuredHeight = height;
              ScrollTrigger.refresh();
            }
          },
        },
      })
        .fromTo(heading, { fontSize: context.conditions.large ? 195 : 70 }, { fontSize: 70, duration: 16, ease: "power1.inOut" }, 20)
        .to({}, { duration: 64 }, 36);
      measuredHeight = section.offsetHeight;
      gsap.from(section.querySelector(".work-header p"), {
        y: 100, opacity: 0, duration: 1, delay: 0.1, ease: "power3.out",
        scrollTrigger: { trigger: section.querySelector(".work-header p"), start: "top 88%", once: true },
      });
      section.querySelectorAll<HTMLElement>(".work-item").forEach((item) => {
        gsap.from(item, {
          y: 100, opacity: 0, duration: 1, delay: 0.1, ease: "power3.out",
          scrollTrigger: { trigger: item, start: "top 88%", once: true },
        });
        gsap.from(item.querySelector(".work-title-motion"), {
          x: 30, duration: 0.8, delay: 0.3, ease: "power1.inOut",
          scrollTrigger: { trigger: item, start: "top bottom", once: true },
        });
        gsap.from(item.querySelector(".work-tag"), {
          yPercent: 50, opacity: 0, duration: 0.7, delay: 0.1, ease: "power1.inOut",
          scrollTrigger: { trigger: item.querySelector(".work-tag-wrap"), start: "top bottom", once: true },
        });
      });
    }, section);
    return () => media.revert();
  }, [ref]);
}

export function useProcessWall(ref: RefObject<HTMLElement | null>) {
  useLayoutEffect(() => {
    const section = ref.current;
    if (!section) return;
    const media = gsap.matchMedia();
    media.add({ desktop: "(min-width: 992px)", reduced: "(prefers-reduced-motion: reduce)" }, (context) => {
      if (context.conditions?.reduced) return;
      gsap.from(section.querySelectorAll(".process-wall-heading > *"), {
        y: 32, opacity: 0, stagger: 0.12, duration: 0.75,
        scrollTrigger: { trigger: section, start: "top top", once: true },
      });
      if (!context.conditions?.desktop) return;
      const cards = section.querySelectorAll<HTMLElement>(".process-wall-card");
      const timeline = gsap.timeline({
        defaults: { ease: "none" },
        scrollTrigger: { trigger: section, start: "top top", end: "bottom bottom", scrub: 1.4, invalidateOnRefresh: true },
      });
      // Begin the reference's moving phase only after the section is pinned.
      const frames = [
        { from: 0, to: -50, start: 0, end: 32 },
        { from: 0, to: -50, start: 0, end: 40 },
        { from: 0, to: -100, start: 0, end: 30 },
        { from: 0, to: -100, start: 0, end: 22 },
        { from: 100, to: 0, start: 0, end: 42 },
        { from: 100, to: 0, start: 0, end: 27 },
        { from: 50, to: 0, start: 0, end: 36 },
        { from: 60, to: 0, start: 0, end: 25 },
      ];
      frames.forEach((frame, index) => {
        timeline.fromTo(cards[index], { y: `${frame.from}vh` }, {
          y: `${frame.to}vh`, duration: frame.end - frame.start,
        }, frame.start);
      });
      timeline.to({}, { duration: 30 }, 42);
    }, section);
    return () => media.revert();
  }, [ref]);
}

export function useTestimonialStack(ref: RefObject<HTMLElement | null>) {
  useLayoutEffect(() => {
    const section = ref.current;
    if (!section) return;
    const media = gsap.matchMedia();
    media.add({ desktop: "(min-width: 992px)", reduced: "(prefers-reduced-motion: reduce)" }, (context) => {
      if (!context.conditions?.desktop || context.conditions.reduced) return;
      const cards = section.querySelectorAll<HTMLElement>(".testimonial-stack-item");
      gsap.set(cards, { y: "100vh" });
      const timeline = gsap.timeline({
        defaults: { ease: "none" },
        scrollTrigger: { trigger: section, start: "top top", end: "bottom bottom", scrub: 0.8, invalidateOnRefresh: true },
      });
      // Keep the stacking order, without consuming progress before arrival.
      timeline
        .to(cards[0], { y: 0, scale: 0.9, duration: 15 }, 0)
        .to(cards[1], { y: 0, scale: 0.95, duration: 15 }, 15)
        .to(cards[2], { y: 0, duration: 10 }, 30)
        .to({}, { duration: 30 }, 40);
    }, section);
    return () => media.revert();
  }, [ref]);
}
