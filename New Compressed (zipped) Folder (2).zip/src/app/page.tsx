import Navbar from "@/components/layout/Navbar";
import Hero from "@/components/sections/Hero";
import Statement from "@/components/sections/Statement";
import Portfolio from "@/components/sections/Portfolio";
import Services from "@/components/sections/Services";
import BrandVision from "@/components/sections/BrandVision";
import Process from "@/components/sections/Process";
import TechStack from "@/components/sections/TechStack";
import Testimonials from "@/components/sections/Testimonials";
import CallToAction from "@/components/sections/CallToAction";
import Footer from "@/components/layout/Footer";

export default function Home() {
  return (
    <>
      <Navbar />
      <main>
        <Hero />
        <Statement />
        <Portfolio />
        <Services />
        <BrandVision />
        <Process />
        <TechStack />
        <Testimonials />
        <CallToAction />
      </main>
      <Footer />
    </>
  );
}
